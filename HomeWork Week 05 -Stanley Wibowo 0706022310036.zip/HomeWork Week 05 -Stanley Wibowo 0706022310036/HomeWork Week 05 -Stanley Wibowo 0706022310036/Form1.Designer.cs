﻿namespace HomeWork_Week_05__Stanley_Wibowo_0706022310036
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_product = new System.Windows.Forms.Label();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.Combox_filter = new System.Windows.Forms.ComboBox();
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            this.tb_category = new System.Windows.Forms.TextBox();
            this.tb_Namaproduct2 = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.combox_category = new System.Windows.Forms.ComboBox();
            this.lbl_namaProduct = new System.Windows.Forms.Label();
            this.lbl_namaproduct2 = new System.Windows.Forms.Label();
            this.lblcategory = new System.Windows.Forms.Label();
            this.lbl_harga = new System.Windows.Forms.Label();
            this.lb_stoct = new System.Windows.Forms.Label();
            this.btn_addcategory = new System.Windows.Forms.Button();
            this.btn_removecategory = new System.Windows.Forms.Button();
            this.btn_addproduct = new System.Windows.Forms.Button();
            this.btn_editproduct = new System.Windows.Forms.Button();
            this.btn_removeproduct = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_product
            // 
            this.lbl_product.AutoSize = true;
            this.lbl_product.Location = new System.Drawing.Point(12, 9);
            this.lbl_product.Name = "lbl_product";
            this.lbl_product.Size = new System.Drawing.Size(53, 16);
            this.lbl_product.TabIndex = 0;
            this.lbl_product.Text = "Product";
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.Location = new System.Drawing.Point(483, 9);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(62, 16);
            this.lbl_Category.TabIndex = 1;
            this.lbl_Category.Text = "Category";
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(129, 12);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(43, 24);
            this.btn_all.TabIndex = 2;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(178, 12);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(66, 24);
            this.btn_filter.TabIndex = 3;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            // 
            // Combox_filter
            // 
            this.Combox_filter.FormattingEnabled = true;
            this.Combox_filter.Location = new System.Drawing.Point(250, 12);
            this.Combox_filter.Name = "Combox_filter";
            this.Combox_filter.Size = new System.Drawing.Size(116, 24);
            this.Combox_filter.TabIndex = 4;
            this.Combox_filter.SelectionChangeCommitted += new System.EventHandler(this.Combox_filter_SelectionChangeCommitted);
            // 
            // dgv_product
            // 
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_product.Location = new System.Drawing.Point(12, 42);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.RowHeadersWidth = 51;
            this.dgv_product.RowTemplate.Height = 24;
            this.dgv_product.Size = new System.Drawing.Size(428, 213);
            this.dgv_product.TabIndex = 5;
            this.dgv_product.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_product_CellMouseClick);
            // 
            // dgv_category
            // 
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_category.Location = new System.Drawing.Point(486, 28);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.RowHeadersWidth = 51;
            this.dgv_category.RowTemplate.Height = 24;
            this.dgv_category.Size = new System.Drawing.Size(309, 172);
            this.dgv_category.TabIndex = 6;
            // 
            // tb_category
            // 
            this.tb_category.Location = new System.Drawing.Point(588, 213);
            this.tb_category.Name = "tb_category";
            this.tb_category.Size = new System.Drawing.Size(199, 22);
            this.tb_category.TabIndex = 7;
            // 
            // tb_Namaproduct2
            // 
            this.tb_Namaproduct2.Location = new System.Drawing.Point(117, 274);
            this.tb_Namaproduct2.Name = "tb_Namaproduct2";
            this.tb_Namaproduct2.Size = new System.Drawing.Size(258, 22);
            this.tb_Namaproduct2.TabIndex = 8;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(72, 352);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(123, 22);
            this.tb_harga.TabIndex = 9;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(72, 389);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(123, 22);
            this.tb_stock.TabIndex = 10;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // combox_category
            // 
            this.combox_category.FormattingEnabled = true;
            this.combox_category.Location = new System.Drawing.Point(86, 312);
            this.combox_category.Name = "combox_category";
            this.combox_category.Size = new System.Drawing.Size(123, 24);
            this.combox_category.TabIndex = 11;
            // 
            // lbl_namaProduct
            // 
            this.lbl_namaProduct.AutoSize = true;
            this.lbl_namaProduct.Location = new System.Drawing.Point(483, 213);
            this.lbl_namaProduct.Name = "lbl_namaProduct";
            this.lbl_namaProduct.Size = new System.Drawing.Size(99, 16);
            this.lbl_namaProduct.TabIndex = 12;
            this.lbl_namaProduct.Text = "Nama Product :";
            // 
            // lbl_namaproduct2
            // 
            this.lbl_namaproduct2.AutoSize = true;
            this.lbl_namaproduct2.Location = new System.Drawing.Point(12, 277);
            this.lbl_namaproduct2.Name = "lbl_namaproduct2";
            this.lbl_namaproduct2.Size = new System.Drawing.Size(99, 16);
            this.lbl_namaproduct2.TabIndex = 13;
            this.lbl_namaproduct2.Text = "Nama Product :";
            // 
            // lblcategory
            // 
            this.lblcategory.AutoSize = true;
            this.lblcategory.BackColor = System.Drawing.Color.Fuchsia;
            this.lblcategory.Location = new System.Drawing.Point(12, 315);
            this.lblcategory.Name = "lblcategory";
            this.lblcategory.Size = new System.Drawing.Size(68, 16);
            this.lblcategory.TabIndex = 14;
            this.lblcategory.Text = "Category :";
            // 
            // lbl_harga
            // 
            this.lbl_harga.AutoSize = true;
            this.lbl_harga.Location = new System.Drawing.Point(12, 358);
            this.lbl_harga.Name = "lbl_harga";
            this.lbl_harga.Size = new System.Drawing.Size(51, 16);
            this.lbl_harga.TabIndex = 15;
            this.lbl_harga.Text = "Harga :";
            // 
            // lb_stoct
            // 
            this.lb_stoct.AutoSize = true;
            this.lb_stoct.Location = new System.Drawing.Point(12, 395);
            this.lb_stoct.Name = "lb_stoct";
            this.lb_stoct.Size = new System.Drawing.Size(47, 16);
            this.lb_stoct.TabIndex = 16;
            this.lb_stoct.Text = "Stock :";
            // 
            // btn_addcategory
            // 
            this.btn_addcategory.Location = new System.Drawing.Point(588, 253);
            this.btn_addcategory.Name = "btn_addcategory";
            this.btn_addcategory.Size = new System.Drawing.Size(84, 64);
            this.btn_addcategory.TabIndex = 17;
            this.btn_addcategory.Text = "Add\r\nCategory";
            this.btn_addcategory.UseVisualStyleBackColor = true;
            this.btn_addcategory.Click += new System.EventHandler(this.btn_addcategory_Click);
            // 
            // btn_removecategory
            // 
            this.btn_removecategory.Location = new System.Drawing.Point(701, 253);
            this.btn_removecategory.Name = "btn_removecategory";
            this.btn_removecategory.Size = new System.Drawing.Size(87, 64);
            this.btn_removecategory.TabIndex = 18;
            this.btn_removecategory.Text = "Remove\r\nCategory";
            this.btn_removecategory.UseVisualStyleBackColor = true;
            this.btn_removecategory.Click += new System.EventHandler(this.btn_removecategory_Click);
            // 
            // btn_addproduct
            // 
            this.btn_addproduct.Location = new System.Drawing.Point(222, 351);
            this.btn_addproduct.Name = "btn_addproduct";
            this.btn_addproduct.Size = new System.Drawing.Size(75, 60);
            this.btn_addproduct.TabIndex = 19;
            this.btn_addproduct.Text = "Add \r\nProduct\r\n";
            this.btn_addproduct.UseVisualStyleBackColor = true;
            this.btn_addproduct.Click += new System.EventHandler(this.btn_addproduct_Click);
            // 
            // btn_editproduct
            // 
            this.btn_editproduct.Location = new System.Drawing.Point(301, 351);
            this.btn_editproduct.Name = "btn_editproduct";
            this.btn_editproduct.Size = new System.Drawing.Size(75, 60);
            this.btn_editproduct.TabIndex = 20;
            this.btn_editproduct.Text = "Edit\r\nProduct\r\n";
            this.btn_editproduct.UseVisualStyleBackColor = true;
            this.btn_editproduct.Click += new System.EventHandler(this.btn_editproduct_Click);
            // 
            // btn_removeproduct
            // 
            this.btn_removeproduct.Location = new System.Drawing.Point(382, 352);
            this.btn_removeproduct.Name = "btn_removeproduct";
            this.btn_removeproduct.Size = new System.Drawing.Size(75, 59);
            this.btn_removeproduct.TabIndex = 21;
            this.btn_removeproduct.Text = "Remove\r\nProduct\r\n";
            this.btn_removeproduct.UseVisualStyleBackColor = true;
            this.btn_removeproduct.Click += new System.EventHandler(this.btn_removeproduct_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Fuchsia;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_removeproduct);
            this.Controls.Add(this.btn_editproduct);
            this.Controls.Add(this.btn_addproduct);
            this.Controls.Add(this.btn_removecategory);
            this.Controls.Add(this.btn_addcategory);
            this.Controls.Add(this.lb_stoct);
            this.Controls.Add(this.lbl_harga);
            this.Controls.Add(this.lblcategory);
            this.Controls.Add(this.combox_category);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_Namaproduct2);
            this.Controls.Add(this.tb_category);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.Combox_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.lbl_Category);
            this.Controls.Add(this.lbl_product);
            this.Controls.Add(this.lbl_namaproduct2);
            this.Controls.Add(this.lbl_namaProduct);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_product;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox Combox_filter;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.DataGridView dgv_category;
        private System.Windows.Forms.TextBox tb_category;
        private System.Windows.Forms.TextBox tb_Namaproduct2;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.ComboBox combox_category;
        private System.Windows.Forms.Label lbl_namaProduct;
        private System.Windows.Forms.Label lbl_namaproduct2;
        private System.Windows.Forms.Label lblcategory;
        private System.Windows.Forms.Label lbl_harga;
        private System.Windows.Forms.Label lb_stoct;
        private System.Windows.Forms.Button btn_addcategory;
        private System.Windows.Forms.Button btn_removecategory;
        private System.Windows.Forms.Button btn_addproduct;
        private System.Windows.Forms.Button btn_editproduct;
        private System.Windows.Forms.Button btn_removeproduct;
    }
}

