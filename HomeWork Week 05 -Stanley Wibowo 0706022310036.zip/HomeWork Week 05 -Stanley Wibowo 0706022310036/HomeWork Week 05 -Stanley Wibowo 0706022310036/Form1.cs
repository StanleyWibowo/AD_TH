﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork_Week_05__Stanley_Wibowo_0706022310036
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataTable dtSimpanProduct = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();

        public List<string> listIDproduct = new List<string>();
        public List<string> listnamaproduct = new List<string>();
        public List<Int64> listharga = new List<Int64>();
        public List<Int32> liststock = new List<Int32>();
        public List<string> listIDcategoryproduct = new List<string>();

        public List<string> listIDcategorycategory = new List<string>();
        public List<string> listnamacategory = new List<string>();

        public bool ceksama = true;
        public int idproductbaru;
        public string selectedcell;
        public string hurufpertama;
        string angka0id = "00";
       

        private void Form1_Load(object sender, EventArgs e)
        {
            dtSimpanProduct.Columns.Add("ID Product");
            dtSimpanProduct.Columns.Add("Nama Product");
            dtSimpanProduct.Columns.Add("Harga");
            dtSimpanProduct.Columns.Add("Stock");
            dtSimpanProduct.Columns.Add("ID Category");

            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            listIDcategorycategory.Add("C1");
            listIDcategorycategory.Add("C2");
            listIDcategorycategory.Add("C3");
            listIDcategorycategory.Add("C4");
            listIDcategorycategory.Add("C5");
            listnamacategory.Add("Jas");
            listnamacategory.Add("T-Shirt");
            listnamacategory.Add("Rok");
            listnamacategory.Add("Celana");
            listnamacategory.Add("Cawat");

            listIDproduct.Add("J001");
            listIDproduct.Add("T001");
            listIDproduct.Add("T002");
            listIDproduct.Add("R001");
            listIDproduct.Add("J002");
            listIDproduct.Add("C001");
            listIDproduct.Add("C002");
            listIDproduct.Add("R002");
            listnamaproduct.Add("Jas Hitam");
            listnamaproduct.Add("T-Shirt Blackpink");
            listnamaproduct.Add("T-Shirt Obsessive");
            listnamaproduct.Add("Rok Mini");
            listnamaproduct.Add("Jeans Biru");
            listnamaproduct.Add("Celana Pendek Coklat");
            listnamaproduct.Add("Cawat Blink-blink");
            listnamaproduct.Add("Rocca Shirt");
            listharga.Add(100000);
            listharga.Add(70000);
            listharga.Add(75000);
            listharga.Add(82000);
            listharga.Add(90000);
            listharga.Add(60000);
            listharga.Add(1000000);
            listharga.Add(50000);
            liststock.Add(10);
            liststock.Add(20);
            liststock.Add(16);
            liststock.Add(26);
            liststock.Add(5);
            liststock.Add(11);
            liststock.Add(1);
            liststock.Add(8);
            listIDcategoryproduct.Add("C1");
            listIDcategoryproduct.Add("C2");
            listIDcategoryproduct.Add("C2");
            listIDcategoryproduct.Add("C3");
            listIDcategoryproduct.Add("C4");
            listIDcategoryproduct.Add("C4");
            listIDcategoryproduct.Add("C5");
            listIDcategoryproduct.Add("C2");

            for (int i = 0; i < listIDcategorycategory.Count; i++)
            {
                dtCategory.Rows.Add(listIDcategorycategory[i], listnamacategory[i]);
                combox_category.Items.Add(listnamacategory[i]);
                Combox_filter.Items.Add(listnamacategory[i]);
            }
            for (int i = 0; i < listIDcategoryproduct.Count; i++)
            {

                dtSimpanProduct.Rows.Add(listIDproduct[i], listnamaproduct[i], listharga[i], liststock[i], listIDcategoryproduct[i]);
            }

            dgv_category.DataSource = dtCategory;
            dgv_product.DataSource = dtSimpanProduct;
            dgv_category.ClearSelection();
            dgv_product.ClearSelection();
            dgv_category.CurrentCell = null;
            dgv_product.CurrentCell = null;
        }

        private void btn_addproduct_Click(object sender, EventArgs e)
        {

            if (tb_Namaproduct2 .Text == "" && tb_harga.Text == "" && tb_stock.Text == "" && combox_category.SelectedValue == null)
            {
                MessageBox.Show("Fill all of the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                hurufpertama = tb_Namaproduct2.Text.Substring(0, 1).ToUpper();

                for (int i = 0; i < listIDproduct.Count; i++)
                {
                    if (tb_Namaproduct2.Text == listnamaproduct[i])
                    {
                        ceksama = false;
                    }

                }

                for (int i = 0; i < listIDproduct.Count; i++)
                {
                    if (tb_Namaproduct2.Text.Substring(0, 1).ToUpper() == listIDproduct[i].Substring(0, 1).ToUpper())
                    {
                        idproductbaru = Convert.ToInt32(listIDproduct[i].Substring(1)) + 1;
                    }
                }
                if (idproductbaru > 99)
                {
                    angka0id = "";
                }
                else if (idproductbaru > 9)
                {
                    angka0id = "0";
                }

                listIDproduct.Add(tb_Namaproduct2.Text.Substring(0, 1).ToUpper() + angka0id + idproductbaru);
                listnamaproduct.Add(tb_Namaproduct2.Text);
                listharga.Add(Convert.ToInt64(tb_harga.Text));
                liststock.Add(Convert.ToInt32(tb_stock.Text));
                listIDcategoryproduct.Add(listIDcategorycategory[combox_category.SelectedIndex]);

                dtSimpanProduct.Rows.Clear();
                for (int i = 0; i < listnamaproduct.Count; i++)
                {
                    dtSimpanProduct.Rows.Add(listIDproduct[i], listnamaproduct[i], listharga[i], liststock[i], listIDcategoryproduct[i]);
                }

                tb_Namaproduct2.Text = null;
                tb_harga.Text = null;
                tb_stock.Text = null;
                combox_category.Text = null;

            }
        }

        private void btn_editproduct_Click(object sender, EventArgs e)
        {
            if (dgv_product.CurrentCell == null)
            {
                MessageBox.Show("You Need To Select First", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (tb_Namaproduct2.Text == "" || tb_harga.Text == "" || tb_stock.Text == "" || combox_category.Text == "")
                {
                    MessageBox.Show("Please fill all the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    for (int i = 0; i < listIDproduct.Count; i++)
                    {
                        if (selectedcell == listIDproduct[i])
                        {
                            listnamaproduct[i] = tb_Namaproduct2.Text;
                            listharga[i] = Convert.ToInt64(tb_harga.Text);
                            liststock[i] = Convert.ToInt32(tb_stock.Text);
                            listIDcategoryproduct[i] = listIDcategorycategory[combox_category.SelectedIndex];

                            if (Convert.ToInt32(tb_stock.Text) == 0)
                            {
                                listIDproduct.RemoveAt(i);
                                listnamaproduct.RemoveAt(i);
                                listharga.RemoveAt(i);
                                liststock.RemoveAt(i);
                                listIDcategoryproduct.RemoveAt(i);

                            }
                            tb_Namaproduct2.Text = null;
                            tb_harga.Text = null;
                            tb_stock.Text = null;
                            combox_category.Text = null;

                            dtSimpanProduct.Rows.Clear();
                            for (int j = 0; j < listnamaproduct.Count; j++)
                            {
                                dtSimpanProduct.Rows.Add(listIDproduct[j], listnamaproduct[j], listharga[j], liststock[j], listIDcategoryproduct[j]);
                            }
                        }
                    }

                }
            }
            dgv_product.ClearSelection();
            dgv_product.CurrentCell = null;
        }

        private void btn_removeproduct_Click(object sender, EventArgs e)
        {
            if (dgv_product.CurrentCell == null)
            {
                MessageBox.Show("You Need To Select First", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                for (int i = 0; i < listIDproduct.Count; i++)
                {
                    if (selectedcell == listIDproduct[i])
                    {
                        listIDproduct.RemoveAt(i);
                        listnamaproduct.RemoveAt(i);
                        listharga.RemoveAt(i);
                        liststock.RemoveAt(i);
                        listIDcategoryproduct.RemoveAt(i);
                        tb_Namaproduct2.Text = null;
                        tb_harga.Text = null;
                        tb_stock.Text = null;
                        combox_category.Text = null;

                        dtSimpanProduct.Rows.Clear();
                        for (int j = 0; j < listnamaproduct.Count; j++)
                        {
                            dtSimpanProduct.Rows.Add(listIDproduct[j], listnamaproduct[j], listharga[j], liststock[j], listIDcategoryproduct[j]);
                        }

                        dgv_product.ClearSelection();
                        dgv_product.CurrentCell = null;
                        selectedcell = "";
                    }
                }
            }
        }

        private void btn_addcategory_Click(object sender, EventArgs e)
        {
            string nampung = "";
            ceksama = true;



            if (tb_category.Text == "")
            {
                MessageBox.Show("Please fill all the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                for (int i = 0; i < listIDcategorycategory.Count; i++)
                {
                    nampung = listIDcategorycategory[i].Substring(1);
                }
                string categoryname = tb_category.Text;
                string categoryID = "C" + (Convert.ToInt32(nampung) + 1);

                for (int i = 0; i < listIDcategorycategory.Count; i++)
                {
                    if (categoryname == listnamacategory[i])
                    {
                        ceksama = false;
                    }

                }
                if (ceksama == false)
                {
                    MessageBox.Show("Category name already exist", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    dtCategory.Rows.Add(categoryID, categoryname);
                    listIDcategorycategory.Add("C" + Convert.ToInt32(nampung) + 1);
                    listnamacategory.Add(tb_category.Text);

                    Combox_filter.Items.Clear();
                    for (int i = 0; i < listnamacategory.Count; i++)
                    {
                        Combox_filter.Items.Add(listnamacategory[i]);
                    }

                    combox_category.Items.Clear();
                    for (int i = 0; i < listnamacategory.Count; i++)
                    {
                        combox_category.Items.Add(listnamacategory[i]);
                    }
                }
                tb_category.Clear();
            }
        }

        private void btn_removecategory_Click(object sender, EventArgs e)
        {
            if (dgv_category.CurrentCell == null)
            {
                MessageBox.Show("You Need To Select First", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string selecteditem = listIDcategorycategory[dgv_category.CurrentCell.RowIndex];
                listIDcategorycategory.RemoveAt(dgv_category.CurrentCell.RowIndex);
                listnamacategory.RemoveAt(dgv_category.CurrentCell.RowIndex);
                dtCategory.Rows.RemoveAt(dgv_category.CurrentCell.RowIndex);

                for (int i = listIDcategoryproduct.Count - 1; i >= 0; i--)
                {
                    if (selecteditem == listIDcategoryproduct[i])
                    {
                        dtSimpanProduct.Rows.RemoveAt((int)i);
                        listIDcategoryproduct.RemoveAt(i);
                        listnamaproduct.RemoveAt(i);
                        listharga.RemoveAt(i);
                        liststock.RemoveAt(i);
                        listIDproduct.RemoveAt(i);

                    }
                }
                Combox_filter.Items.Clear();
                for (int i = 0; i < listnamacategory.Count; i++)
                {
                    Combox_filter.Items.Add(listnamacategory[i]);
                }

                combox_category.Items.Clear();
                for (int i = 0; i < listnamacategory.Count; i++)
                {
                    combox_category.Items.Add(listnamacategory[i]);
                }

                dgv_category.ClearSelection();
                dgv_category.CurrentCell = null;
            }
        }

        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void dgv_product_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            selectedcell = dgv_product.SelectedCells[0].Value.ToString();
            if (dgv_product.CurrentCell == null)
            {
                MessageBox.Show("Pilih Dulu Dong Kak :)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                for (int i = 0; i < listIDproduct.Count; i++)
                {
                    if (selectedcell == listIDproduct[i])
                    {
                        tb_Namaproduct2.Text = listnamaproduct[i];
                        tb_harga.Text = listharga[i].ToString();
                        tb_stock.Text = liststock[i].ToString();
                        foreach (DataRow a in dtCategory.Rows)
                        {
                            if (listIDcategoryproduct[i] == a[0].ToString())
                            {
                                combox_category.Text = a[1].ToString();
                            }
                        }
                    }
                }


            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            dtSimpanProduct.Rows.Clear();
            for (int j = 0; j < listnamaproduct.Count; j++)
            {
                dtSimpanProduct.Rows.Add(listIDproduct[j], listnamaproduct[j], listharga[j], liststock[j], listIDcategoryproduct[j]);
            }

            Combox_filter.Text = "";
            Combox_filter.Enabled = false;
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            Combox_filter.Enabled = true;
        }

        private void Combox_filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dtSimpanProduct.Rows.Clear();
            for (int i = 0; i < listIDcategoryproduct.Count; i++)
            {
                if (listIDcategorycategory[Combox_filter.SelectedIndex] == listIDcategoryproduct[i])
                {
                    dtSimpanProduct.Rows.Add(listIDproduct[i], listnamaproduct[i], listharga[i], liststock[i], listIDcategoryproduct[i]);
                }
            }
        }
    }
}
